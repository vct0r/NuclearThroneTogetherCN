Nuclear Throne by Vlambeer, NuclearThroneTogether by YellowAfterLife

hi c:

I made this

	place the folder this file was in into the 'mods' folder that came with the current version of NTT
	'/loadtxt skins'
	in game to load
	requires all players to first enter '/sideload' if playing online
	check the readme in the NTT folder for other commands

it adds 1 to 3 skins for every character in NuclearthroneTogether
so every character has 4 skins, to celebrate YellowAfterlife adding 4 player co-op to the game

my sprite art isnt quite to the level of Paul Veer(NuclearThrone's amazing sprite artist) yet but I'm getting close and learning quick

I put a stupid amount of time into this for no money
please consider commissioning me to do art for you ♥

	email(lol yahoo)
		carboardrobothead@yahoo.com
	
	discord
		blaac#1364
		
	twitter
		https://twitter.com/blaac_
	
	tumblr
		https://13laac.tumblr.com/

		
check out other cool nuclear throne mods made by me or other cool people at 	
	https://bitbucket.org/YellowAfterlife/nuclearthronetogether/wiki/Mods/Mod%20list
	Ctrl+F blaac
	
list of skins added (doesnt include the 3 extra skins added to NuclearThroneTogether by defualt)

	fish       
		vacation        
		grunt        
	eyes      
		blob          
		inspector            
	crystal       
		tree         
		shielder      
	melting 
		glob         
		necromancer             
	plant        
		sapling 
		spider    
	yungvenus
		JW      
	steroids
		cook          
		mimic     
	robot
		turret    
	chicken       	
		jacket             
		bot
	rebel
		jungle    
		raven     
	horror       
		idpdgun
		moni
	rogue
		justins redesign
		roguefreak
	frog
		superfrog
		tiny mom
		a greek god
	skeleton
		blood
		maggot
	also includes a slight fix for the games original portraits that were not drawn with the 4 player character select screen in mind

	to remove a skin, edit the 'main.txt' file
	
	
by blaac
thanks
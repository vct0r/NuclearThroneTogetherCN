=== Instructions ===
1. Install the Nuclear Throne Together mod from: https://yellowafterlife.itch.io/nuclear-throne-together
2. Move the "brucepack" directory to the Nuclear Throne mods folder.
3. Launch the game and press "t" to open a command prompt.
4. Type "/loadtext brucepack" and hit enter.
5. Happy throning :)

=== Mod Changes ===
--- Character Changes ---
  + Fish can dodge roll! (and get dizzy)
  + Robot and Chicken's actives prefer ground weapons.
  + Rogue is stronger against IDPD.
  + Rebel allies have names.
     You can use "/twitchallies <your twitch channel name>" to load viewer names as ally names.

--- Mutation Changes ---
  + Recycle gland absorbs reflected bullets.
  + Euphoria makes enemies think 25% slower.
  + Open Mind prevents Mimic spawns and has a 5% chance of spawning YV chests.
  + Eagle Eyes shows chest/boss indicators and reveals mimics and assassins.
  + Last Wish has 10% chance of activating on every portal.

--- Weapon Changes ---
  + Lightning forks.
  + Secondary weapon reloads at 25% speed in the background.
  + Grenades destroy maggots and weak props without detonating.
  + Toxic gas does no damage until it hits a critical point.

-- Enemy Changes ---
  + Maggots squish underfoot.
  + Flies have 25% less HP.
  + Buff Gator flak does 30% less damage.
